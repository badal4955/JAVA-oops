class A extends Thread{
     public void run(){
          try{               //due to Override method manually Exception used
               for(int i=0; i<=5; i++){
               System.out.println("badal");
               Thread.sleep(1000);
            } 
          }
         catch(InterruptedException i){
              
         }
     }
}
class B{
     public static void main(String []args)throws InterruptedException{ //due to main fun. by caller,or JVM
          A t=new A();
          t.start();
          for(int i=0; i<=5; i++){
               System.out.println("kishan");
                Thread.sleep(1000);
          } 
     }
}