class fun{
    public static void main(String []args){
        fun ob=new fun();
        ob.Disp();
    }
    void Disp(){
        System.out.print("hello");
    }
}