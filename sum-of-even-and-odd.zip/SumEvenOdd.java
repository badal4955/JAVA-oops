import java.util.Scanner;

public class SumEvenOdd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the size of the array: ");
        int size = sc.nextInt();
        int numbers[] = new int[size];

        System.out.println("Enter array elements: ");
        for (int i = 0; i < size; i++) {
            numbers[i] = sc.nextInt();
        }

        int evenSum = 0, oddSum = 0;

        for (int i = 0; i < size; i++) {
            if (numbers[i] % 2 == 0) {
                evenSum += numbers[i];
            } else {
                oddSum += numbers[i];
            }
        }

        System.out.println("Sum of even numbers is: " + evenSum);
        System.out.println("Sum of odd numbers is: " + oddSum);
        
        sc.close();
    }
}
