
class mythread1 extends Thread{
     @Override
     public void run(){
          while(true){
               System.out.println("thread 1");
          }
     } 
}

class mythread2 extends Thread{
     @Override
     public void run(){
          while(true){
               System.out.println("thread 2");
          }
     } 
}
public class doublethread
{
	public static void main(String[] args) {
		mythread1 t1=new mythread1();
		mythread2 t2=new mythread2();
		t1.start();
		t2.start();
	}
}