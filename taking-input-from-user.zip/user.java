import java.util.Scanner;
class user{
     public static void main(String []args){
          System.out.println("Taking input");
     Scanner sc=new Scanner(System.in);
      System.out.println("Enter number 1 :");
     int a = sc.nextInt();
      System.out.println("Enter number 2 :");
     int b = sc.nextInt();
     
     int sum=a+b;
     System.out.println("sum of both input is :"+sum);
     }
}
     