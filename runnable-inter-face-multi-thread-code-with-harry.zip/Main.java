class mythread1 implements Runnable{
     public void run(){
          System.out.println("this is thread 1");
          System.out.println("this is thread 1");
     }
} 
class mythread2 implements Runnable{
     public void run(){
          System.out.println("this is thread 2");
          System.out.println("this is thread 2");
          System.out.println("this is thread 2");
     }
} 
public class Main
{
	public static void main(String[] args) {
	mythread1 t1=new mythread1();
	Thread thr1=new Thread(t1);
	mythread2 t2=new mythread2();
	Thread thr2=new Thread(t2);
	thr1.start();
	thr2.start();
	}
}
