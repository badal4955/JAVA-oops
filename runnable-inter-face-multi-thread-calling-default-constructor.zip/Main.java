class mythread1 implements Runnable{
     public void run(){
          System.out.println("this is thread 1");
          System.out.println("this is thread 1");
     }
} 
class mythread2 implements Runnable{
     public void run(){
          System.out.println("this is thread 2");
          System.out.println("this is thread 2");
          System.out.println("this is thread 2");
     }
} 
public class Main
{
	public static void main(String[] args) {
	Thread thr1=new Thread(new mythread1());
	Thread thr2=new Thread(new mythread2());
	thr1.start();
	thr2.start();
	}
}
