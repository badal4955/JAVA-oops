class InvalidAgeException extends RuntimeException {  // Now unchecked
    public InvalidAgeException(String message) {
        super(message);
    }
}

public class Great {
    public static void validate(int age) {  // No need to declare "throws"
        if (age < 18) {
            throw new InvalidAgeException("Age must be 18 or above");
        }
        System.out.println("Valid age: " + age);
    }

    public static void main(String[] args) {
        try {
            validate(12);
        } catch (InvalidAgeException e) {
            System.out.println("Caught Exception: " + e.getMessage());
        }
    }
}
